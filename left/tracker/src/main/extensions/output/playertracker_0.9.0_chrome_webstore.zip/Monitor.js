KangoAPI.onReady(function () {
    alert(kango.storage.getItem('monitor'));
});

